﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.MetroPanel1 = New MetroFramework.Controls.MetroPanel()
        Me.lbltele = New MetroFramework.Controls.MetroLabel()
        Me.txtuserid = New MetroFramework.Controls.MetroTextBox()
        Me.MetroLabel12 = New MetroFramework.Controls.MetroLabel()
        Me.MetroLabel11 = New MetroFramework.Controls.MetroLabel()
        Me.txttoken = New MetroFramework.Controls.MetroTextBox()
        Me.MetroLabel17 = New MetroFramework.Controls.MetroLabel()
        Me.togtele = New MetroFramework.Controls.MetroToggle()
        Me.MetroButton6 = New MetroFramework.Controls.MetroButton()
        Me.lblnosupSENDSMS = New MetroFramework.Controls.MetroLabel()
        Me.MetroLabel16 = New MetroFramework.Controls.MetroLabel()
        Me.MetroLabel15 = New MetroFramework.Controls.MetroLabel()
        Me.MetroToggle1 = New MetroFramework.Controls.MetroToggle()
        Me.txtFooter = New MetroFramework.Controls.MetroTextBox()
        Me.MetroLabel14 = New MetroFramework.Controls.MetroLabel()
        Me.txtPageTitle = New MetroFramework.Controls.MetroTextBox()
        Me.MetroLabel13 = New MetroFramework.Controls.MetroLabel()
        Me.MetroLabel10 = New MetroFramework.Controls.MetroLabel()
        Me.MetroButton5 = New MetroFramework.Controls.MetroButton()
        Me.MetroTextBox1 = New MetroFramework.Controls.MetroTextBox()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.MetroLabel9 = New MetroFramework.Controls.MetroLabel()
        Me.TogIp = New MetroFramework.Controls.MetroToggle()
        Me.txtmailsubject = New MetroFramework.Controls.MetroTextBox()
        Me.MetroLabel8 = New MetroFramework.Controls.MetroLabel()
        Me.MetroLabel7 = New MetroFramework.Controls.MetroLabel()
        Me.MetroButton4 = New MetroFramework.Controls.MetroButton()
        Me.MetroButton3 = New MetroFramework.Controls.MetroButton()
        Me.btnPreView = New MetroFramework.Controls.MetroButton()
        Me.txtLoading = New MetroFramework.Controls.MetroTextBox()
        Me.MetroLabel6 = New MetroFramework.Controls.MetroLabel()
        Me.txtLog = New MetroFramework.Controls.MetroTextBox()
        Me.MetroButton2 = New MetroFramework.Controls.MetroButton()
        Me.txtNoNet = New MetroFramework.Controls.MetroTextBox()
        Me.MetroLabel5 = New MetroFramework.Controls.MetroLabel()
        Me.txtComp = New MetroFramework.Controls.MetroTextBox()
        Me.MetroLabel4 = New MetroFramework.Controls.MetroLabel()
        Me.txtWelcome = New MetroFramework.Controls.MetroTextBox()
        Me.MetroLabel3 = New MetroFramework.Controls.MetroLabel()
        Me.txtPhpAddress = New MetroFramework.Controls.MetroTextBox()
        Me.MetroLabel2 = New MetroFramework.Controls.MetroLabel()
        Me.txtPhone = New MetroFramework.Controls.MetroTextBox()
        Me.txtMail = New MetroFramework.Controls.MetroTextBox()
        Me.MetroCheckBox2 = New MetroFramework.Controls.MetroCheckBox()
        Me.MetroCheckBox1 = New MetroFramework.Controls.MetroCheckBox()
        Me.pgL = New MetroFramework.Controls.MetroProgressSpinner()
        Me.MetroLabel1 = New MetroFramework.Controls.MetroLabel()
        Me.CnLog = New MetroFramework.Controls.MetroTile()
        Me.btnLoadConfig = New MetroFramework.Controls.MetroButton()
        Me.MetroButton1 = New MetroFramework.Controls.MetroButton()
        Me.CnStatus = New MetroFramework.Controls.MetroTile()
        Me.BtnExit = New MetroFramework.Controls.MetroButton()
        Me.CnTitle = New MetroFramework.Controls.MetroTile()
        Me.OpenFileDialog1 = New System.Windows.Forms.OpenFileDialog()
        Me.MetroPanel1.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'MetroPanel1
        '
        Me.MetroPanel1.Controls.Add(Me.lbltele)
        Me.MetroPanel1.Controls.Add(Me.txtuserid)
        Me.MetroPanel1.Controls.Add(Me.MetroLabel12)
        Me.MetroPanel1.Controls.Add(Me.MetroLabel11)
        Me.MetroPanel1.Controls.Add(Me.txttoken)
        Me.MetroPanel1.Controls.Add(Me.MetroLabel17)
        Me.MetroPanel1.Controls.Add(Me.togtele)
        Me.MetroPanel1.Controls.Add(Me.MetroButton6)
        Me.MetroPanel1.Controls.Add(Me.lblnosupSENDSMS)
        Me.MetroPanel1.Controls.Add(Me.MetroLabel16)
        Me.MetroPanel1.Controls.Add(Me.MetroLabel15)
        Me.MetroPanel1.Controls.Add(Me.MetroToggle1)
        Me.MetroPanel1.Controls.Add(Me.txtFooter)
        Me.MetroPanel1.Controls.Add(Me.MetroLabel14)
        Me.MetroPanel1.Controls.Add(Me.txtPageTitle)
        Me.MetroPanel1.Controls.Add(Me.MetroLabel13)
        Me.MetroPanel1.Controls.Add(Me.MetroLabel10)
        Me.MetroPanel1.Controls.Add(Me.MetroButton5)
        Me.MetroPanel1.Controls.Add(Me.MetroTextBox1)
        Me.MetroPanel1.Controls.Add(Me.PictureBox1)
        Me.MetroPanel1.Controls.Add(Me.MetroLabel9)
        Me.MetroPanel1.Controls.Add(Me.TogIp)
        Me.MetroPanel1.Controls.Add(Me.txtmailsubject)
        Me.MetroPanel1.Controls.Add(Me.MetroLabel8)
        Me.MetroPanel1.Controls.Add(Me.MetroLabel7)
        Me.MetroPanel1.Controls.Add(Me.MetroButton4)
        Me.MetroPanel1.Controls.Add(Me.MetroButton3)
        Me.MetroPanel1.Controls.Add(Me.btnPreView)
        Me.MetroPanel1.Controls.Add(Me.txtLoading)
        Me.MetroPanel1.Controls.Add(Me.MetroLabel6)
        Me.MetroPanel1.Controls.Add(Me.txtLog)
        Me.MetroPanel1.Controls.Add(Me.MetroButton2)
        Me.MetroPanel1.Controls.Add(Me.txtNoNet)
        Me.MetroPanel1.Controls.Add(Me.MetroLabel5)
        Me.MetroPanel1.Controls.Add(Me.txtComp)
        Me.MetroPanel1.Controls.Add(Me.MetroLabel4)
        Me.MetroPanel1.Controls.Add(Me.txtWelcome)
        Me.MetroPanel1.Controls.Add(Me.MetroLabel3)
        Me.MetroPanel1.Controls.Add(Me.txtPhpAddress)
        Me.MetroPanel1.Controls.Add(Me.MetroLabel2)
        Me.MetroPanel1.Controls.Add(Me.txtPhone)
        Me.MetroPanel1.Controls.Add(Me.txtMail)
        Me.MetroPanel1.Controls.Add(Me.MetroCheckBox2)
        Me.MetroPanel1.Controls.Add(Me.MetroCheckBox1)
        Me.MetroPanel1.Controls.Add(Me.pgL)
        Me.MetroPanel1.Controls.Add(Me.MetroLabel1)
        Me.MetroPanel1.Controls.Add(Me.CnLog)
        Me.MetroPanel1.Controls.Add(Me.btnLoadConfig)
        Me.MetroPanel1.Controls.Add(Me.MetroButton1)
        Me.MetroPanel1.Controls.Add(Me.CnStatus)
        Me.MetroPanel1.Controls.Add(Me.BtnExit)
        Me.MetroPanel1.Controls.Add(Me.CnTitle)
        Me.MetroPanel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.MetroPanel1.HorizontalScrollbarBarColor = True
        Me.MetroPanel1.HorizontalScrollbarHighlightOnWheel = False
        Me.MetroPanel1.HorizontalScrollbarSize = 10
        Me.MetroPanel1.Location = New System.Drawing.Point(0, 0)
        Me.MetroPanel1.Name = "MetroPanel1"
        Me.MetroPanel1.Size = New System.Drawing.Size(616, 611)
        Me.MetroPanel1.Style = MetroFramework.MetroColorStyle.Blue
        Me.MetroPanel1.TabIndex = 0
        Me.MetroPanel1.Theme = MetroFramework.MetroThemeStyle.Dark
        Me.MetroPanel1.VerticalScrollbarBarColor = True
        Me.MetroPanel1.VerticalScrollbarHighlightOnWheel = False
        Me.MetroPanel1.VerticalScrollbarSize = 10
        '
        'lbltele
        '
        Me.lbltele.AutoSize = True
        Me.lbltele.Location = New System.Drawing.Point(218, 303)
        Me.lbltele.Name = "lbltele"
        Me.lbltele.Size = New System.Drawing.Size(172, 19)
        Me.lbltele.Style = MetroFramework.MetroColorStyle.Red
        Me.lbltele.TabIndex = 60
        Me.lbltele.Text = "This Config Doesn't Support"
        Me.lbltele.Theme = MetroFramework.MetroThemeStyle.Dark
        Me.lbltele.UseStyleColors = True
        Me.lbltele.Visible = False
        '
        'txtuserid
        '
        Me.txtuserid.Location = New System.Drawing.Point(308, 331)
        Me.txtuserid.Name = "txtuserid"
        Me.txtuserid.Size = New System.Drawing.Size(198, 23)
        Me.txtuserid.Style = MetroFramework.MetroColorStyle.Lime
        Me.txtuserid.TabIndex = 59
        Me.txtuserid.Theme = MetroFramework.MetroThemeStyle.Dark
        Me.txtuserid.UseStyleColors = True
        '
        'MetroLabel12
        '
        Me.MetroLabel12.AutoSize = True
        Me.MetroLabel12.Location = New System.Drawing.Point(248, 332)
        Me.MetroLabel12.Name = "MetroLabel12"
        Me.MetroLabel12.Size = New System.Drawing.Size(62, 19)
        Me.MetroLabel12.Style = MetroFramework.MetroColorStyle.Lime
        Me.MetroLabel12.TabIndex = 58
        Me.MetroLabel12.Text = "User ID : "
        Me.MetroLabel12.Theme = MetroFramework.MetroThemeStyle.Dark
        Me.MetroLabel12.UseStyleColors = True
        '
        'MetroLabel11
        '
        Me.MetroLabel11.AutoSize = True
        Me.MetroLabel11.Location = New System.Drawing.Point(8, 335)
        Me.MetroLabel11.Name = "MetroLabel11"
        Me.MetroLabel11.Size = New System.Drawing.Size(73, 19)
        Me.MetroLabel11.Style = MetroFramework.MetroColorStyle.Lime
        Me.MetroLabel11.TabIndex = 57
        Me.MetroLabel11.Text = "Bot Token :"
        Me.MetroLabel11.Theme = MetroFramework.MetroThemeStyle.Dark
        Me.MetroLabel11.UseStyleColors = True
        '
        'txttoken
        '
        Me.txttoken.Location = New System.Drawing.Point(84, 331)
        Me.txttoken.Name = "txttoken"
        Me.txttoken.Size = New System.Drawing.Size(158, 23)
        Me.txttoken.Style = MetroFramework.MetroColorStyle.Lime
        Me.txttoken.TabIndex = 56
        Me.txttoken.Theme = MetroFramework.MetroThemeStyle.Dark
        Me.txttoken.UseStyleColors = True
        '
        'MetroLabel17
        '
        Me.MetroLabel17.AutoSize = True
        Me.MetroLabel17.Location = New System.Drawing.Point(8, 302)
        Me.MetroLabel17.Name = "MetroLabel17"
        Me.MetroLabel17.Size = New System.Drawing.Size(124, 19)
        Me.MetroLabel17.Style = MetroFramework.MetroColorStyle.Lime
        Me.MetroLabel17.TabIndex = 55
        Me.MetroLabel17.Text = "Send To Telegram : "
        Me.MetroLabel17.Theme = MetroFramework.MetroThemeStyle.Dark
        Me.MetroLabel17.UseStyleColors = True
        '
        'togtele
        '
        Me.togtele.AutoSize = True
        Me.togtele.Location = New System.Drawing.Point(132, 305)
        Me.togtele.Name = "togtele"
        Me.togtele.Size = New System.Drawing.Size(80, 17)
        Me.togtele.Style = MetroFramework.MetroColorStyle.Lime
        Me.togtele.TabIndex = 54
        Me.togtele.Text = "Off"
        Me.togtele.Theme = MetroFramework.MetroThemeStyle.Dark
        Me.togtele.UseStyleColors = True
        Me.togtele.UseVisualStyleBackColor = True
        '
        'MetroButton6
        '
        Me.MetroButton6.Highlight = True
        Me.MetroButton6.Location = New System.Drawing.Point(425, 273)
        Me.MetroButton6.Name = "MetroButton6"
        Me.MetroButton6.Size = New System.Drawing.Size(81, 23)
        Me.MetroButton6.Style = MetroFramework.MetroColorStyle.Red
        Me.MetroButton6.TabIndex = 53
        Me.MetroButton6.Text = "Default Icon"
        Me.MetroButton6.Theme = MetroFramework.MetroThemeStyle.Dark
        '
        'lblnosupSENDSMS
        '
        Me.lblnosupSENDSMS.AutoSize = True
        Me.lblnosupSENDSMS.Location = New System.Drawing.Point(272, 129)
        Me.lblnosupSENDSMS.Name = "lblnosupSENDSMS"
        Me.lblnosupSENDSMS.Size = New System.Drawing.Size(172, 19)
        Me.lblnosupSENDSMS.Style = MetroFramework.MetroColorStyle.Red
        Me.lblnosupSENDSMS.TabIndex = 52
        Me.lblnosupSENDSMS.Text = "This Config Doesn't Support"
        Me.lblnosupSENDSMS.Theme = MetroFramework.MetroThemeStyle.Dark
        Me.lblnosupSENDSMS.UseStyleColors = True
        Me.lblnosupSENDSMS.Visible = False
        '
        'MetroLabel16
        '
        Me.MetroLabel16.AutoSize = True
        Me.MetroLabel16.Location = New System.Drawing.Point(238, 490)
        Me.MetroLabel16.Name = "MetroLabel16"
        Me.MetroLabel16.Size = New System.Drawing.Size(172, 19)
        Me.MetroLabel16.Style = MetroFramework.MetroColorStyle.Red
        Me.MetroLabel16.TabIndex = 51
        Me.MetroLabel16.Text = "This Config Doesn't Support"
        Me.MetroLabel16.Theme = MetroFramework.MetroThemeStyle.Dark
        Me.MetroLabel16.UseStyleColors = True
        Me.MetroLabel16.Visible = False
        '
        'MetroLabel15
        '
        Me.MetroLabel15.AutoSize = True
        Me.MetroLabel15.Location = New System.Drawing.Point(238, 472)
        Me.MetroLabel15.Name = "MetroLabel15"
        Me.MetroLabel15.Size = New System.Drawing.Size(150, 19)
        Me.MetroLabel15.Style = MetroFramework.MetroColorStyle.Lime
        Me.MetroLabel15.TabIndex = 50
        Me.MetroLabel15.Text = "Capture Phone Details : "
        Me.MetroLabel15.Theme = MetroFramework.MetroThemeStyle.Dark
        Me.MetroLabel15.UseStyleColors = True
        '
        'MetroToggle1
        '
        Me.MetroToggle1.AutoSize = True
        Me.MetroToggle1.Location = New System.Drawing.Point(385, 473)
        Me.MetroToggle1.Name = "MetroToggle1"
        Me.MetroToggle1.Size = New System.Drawing.Size(80, 17)
        Me.MetroToggle1.Style = MetroFramework.MetroColorStyle.Lime
        Me.MetroToggle1.TabIndex = 49
        Me.MetroToggle1.Text = "Off"
        Me.MetroToggle1.Theme = MetroFramework.MetroThemeStyle.Dark
        Me.MetroToggle1.UseStyleColors = True
        Me.MetroToggle1.UseVisualStyleBackColor = True
        '
        'txtFooter
        '
        Me.txtFooter.Location = New System.Drawing.Point(84, 389)
        Me.txtFooter.Name = "txtFooter"
        Me.txtFooter.Size = New System.Drawing.Size(518, 23)
        Me.txtFooter.Style = MetroFramework.MetroColorStyle.Lime
        Me.txtFooter.TabIndex = 47
        Me.txtFooter.Theme = MetroFramework.MetroThemeStyle.Dark
        Me.txtFooter.UseStyleColors = True
        '
        'MetroLabel14
        '
        Me.MetroLabel14.AutoSize = True
        Me.MetroLabel14.Location = New System.Drawing.Point(8, 390)
        Me.MetroLabel14.Name = "MetroLabel14"
        Me.MetroLabel14.Size = New System.Drawing.Size(59, 19)
        Me.MetroLabel14.Style = MetroFramework.MetroColorStyle.Lime
        Me.MetroLabel14.TabIndex = 46
        Me.MetroLabel14.Text = "Footer : "
        Me.MetroLabel14.Theme = MetroFramework.MetroThemeStyle.Dark
        Me.MetroLabel14.UseStyleColors = True
        '
        'txtPageTitle
        '
        Me.txtPageTitle.Location = New System.Drawing.Point(84, 360)
        Me.txtPageTitle.Name = "txtPageTitle"
        Me.txtPageTitle.Size = New System.Drawing.Size(518, 23)
        Me.txtPageTitle.Style = MetroFramework.MetroColorStyle.Lime
        Me.txtPageTitle.TabIndex = 45
        Me.txtPageTitle.Theme = MetroFramework.MetroThemeStyle.Dark
        Me.txtPageTitle.UseStyleColors = True
        '
        'MetroLabel13
        '
        Me.MetroLabel13.AutoSize = True
        Me.MetroLabel13.Location = New System.Drawing.Point(8, 361)
        Me.MetroLabel13.Name = "MetroLabel13"
        Me.MetroLabel13.Size = New System.Drawing.Size(77, 19)
        Me.MetroLabel13.Style = MetroFramework.MetroColorStyle.Lime
        Me.MetroLabel13.TabIndex = 44
        Me.MetroLabel13.Text = "Page Title : "
        Me.MetroLabel13.Theme = MetroFramework.MetroThemeStyle.Dark
        Me.MetroLabel13.UseStyleColors = True
        '
        'MetroLabel10
        '
        Me.MetroLabel10.AutoSize = True
        Me.MetroLabel10.Location = New System.Drawing.Point(8, 275)
        Me.MetroLabel10.Name = "MetroLabel10"
        Me.MetroLabel10.Size = New System.Drawing.Size(44, 19)
        Me.MetroLabel10.Style = MetroFramework.MetroColorStyle.Lime
        Me.MetroLabel10.TabIndex = 39
        Me.MetroLabel10.Text = "Icon : "
        Me.MetroLabel10.Theme = MetroFramework.MetroThemeStyle.Dark
        Me.MetroLabel10.UseStyleColors = True
        '
        'MetroButton5
        '
        Me.MetroButton5.Highlight = True
        Me.MetroButton5.Location = New System.Drawing.Point(391, 273)
        Me.MetroButton5.Name = "MetroButton5"
        Me.MetroButton5.Size = New System.Drawing.Size(28, 23)
        Me.MetroButton5.Style = MetroFramework.MetroColorStyle.Red
        Me.MetroButton5.TabIndex = 38
        Me.MetroButton5.Text = "..."
        Me.MetroButton5.Theme = MetroFramework.MetroThemeStyle.Dark
        '
        'MetroTextBox1
        '
        Me.MetroTextBox1.Location = New System.Drawing.Point(62, 273)
        Me.MetroTextBox1.Name = "MetroTextBox1"
        Me.MetroTextBox1.ReadOnly = True
        Me.MetroTextBox1.Size = New System.Drawing.Size(323, 23)
        Me.MetroTextBox1.Style = MetroFramework.MetroColorStyle.Lime
        Me.MetroTextBox1.TabIndex = 37
        Me.MetroTextBox1.Theme = MetroFramework.MetroThemeStyle.Dark
        Me.MetroTextBox1.UseStyleColors = True
        '
        'PictureBox1
        '
        Me.PictureBox1.BackColor = System.Drawing.Color.Transparent
        Me.PictureBox1.Location = New System.Drawing.Point(512, 273)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(90, 81)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox1.TabIndex = 36
        Me.PictureBox1.TabStop = False
        '
        'MetroLabel9
        '
        Me.MetroLabel9.AutoSize = True
        Me.MetroLabel9.Location = New System.Drawing.Point(10, 470)
        Me.MetroLabel9.Name = "MetroLabel9"
        Me.MetroLabel9.Size = New System.Drawing.Size(143, 19)
        Me.MetroLabel9.Style = MetroFramework.MetroColorStyle.Lime
        Me.MetroLabel9.TabIndex = 35
        Me.MetroLabel9.Text = "Get Client Ip Address : "
        Me.MetroLabel9.Theme = MetroFramework.MetroThemeStyle.Dark
        Me.MetroLabel9.UseStyleColors = True
        '
        'TogIp
        '
        Me.TogIp.AutoSize = True
        Me.TogIp.Location = New System.Drawing.Point(151, 472)
        Me.TogIp.Name = "TogIp"
        Me.TogIp.Size = New System.Drawing.Size(80, 17)
        Me.TogIp.Style = MetroFramework.MetroColorStyle.Lime
        Me.TogIp.TabIndex = 34
        Me.TogIp.Text = "Off"
        Me.TogIp.Theme = MetroFramework.MetroThemeStyle.Dark
        Me.TogIp.UseStyleColors = True
        Me.TogIp.UseVisualStyleBackColor = True
        '
        'txtmailsubject
        '
        Me.txtmailsubject.Location = New System.Drawing.Point(97, 442)
        Me.txtmailsubject.Name = "txtmailsubject"
        Me.txtmailsubject.Size = New System.Drawing.Size(509, 23)
        Me.txtmailsubject.Style = MetroFramework.MetroColorStyle.Lime
        Me.txtmailsubject.TabIndex = 33
        Me.txtmailsubject.Theme = MetroFramework.MetroThemeStyle.Dark
        Me.txtmailsubject.UseStyleColors = True
        '
        'MetroLabel8
        '
        Me.MetroLabel8.AutoSize = True
        Me.MetroLabel8.Location = New System.Drawing.Point(12, 443)
        Me.MetroLabel8.Name = "MetroLabel8"
        Me.MetroLabel8.Size = New System.Drawing.Size(91, 19)
        Me.MetroLabel8.Style = MetroFramework.MetroColorStyle.Lime
        Me.MetroLabel8.TabIndex = 32
        Me.MetroLabel8.Text = "Mail Subject : "
        Me.MetroLabel8.Theme = MetroFramework.MetroThemeStyle.Dark
        Me.MetroLabel8.UseStyleColors = True
        '
        'MetroLabel7
        '
        Me.MetroLabel7.AutoSize = True
        Me.MetroLabel7.Location = New System.Drawing.Point(12, 417)
        Me.MetroLabel7.Name = "MetroLabel7"
        Me.MetroLabel7.Size = New System.Drawing.Size(97, 19)
        Me.MetroLabel7.Style = MetroFramework.MetroColorStyle.Blue
        Me.MetroLabel7.TabIndex = 31
        Me.MetroLabel7.Text = "Server Options"
        Me.MetroLabel7.Theme = MetroFramework.MetroThemeStyle.Dark
        Me.MetroLabel7.UseStyleColors = True
        '
        'MetroButton4
        '
        Me.MetroButton4.Highlight = True
        Me.MetroButton4.Location = New System.Drawing.Point(265, 2)
        Me.MetroButton4.Name = "MetroButton4"
        Me.MetroButton4.Size = New System.Drawing.Size(130, 21)
        Me.MetroButton4.Style = MetroFramework.MetroColorStyle.Red
        Me.MetroButton4.TabIndex = 30
        Me.MetroButton4.Text = "Get Configs"
        Me.MetroButton4.Theme = MetroFramework.MetroThemeStyle.Dark
        '
        'MetroButton3
        '
        Me.MetroButton3.Highlight = True
        Me.MetroButton3.Location = New System.Drawing.Point(132, 2)
        Me.MetroButton3.Name = "MetroButton3"
        Me.MetroButton3.Size = New System.Drawing.Size(130, 21)
        Me.MetroButton3.Style = MetroFramework.MetroColorStyle.Red
        Me.MetroButton3.TabIndex = 29
        Me.MetroButton3.Text = "Create Config"
        Me.MetroButton3.Theme = MetroFramework.MetroThemeStyle.Dark
        '
        'btnPreView
        '
        Me.btnPreView.Highlight = True
        Me.btnPreView.Location = New System.Drawing.Point(478, 558)
        Me.btnPreView.Name = "btnPreView"
        Me.btnPreView.Size = New System.Drawing.Size(124, 21)
        Me.btnPreView.Style = MetroFramework.MetroColorStyle.Red
        Me.btnPreView.TabIndex = 28
        Me.btnPreView.Text = "Preview"
        Me.btnPreView.Theme = MetroFramework.MetroThemeStyle.Dark
        '
        'txtLoading
        '
        Me.txtLoading.Location = New System.Drawing.Point(147, 244)
        Me.txtLoading.Name = "txtLoading"
        Me.txtLoading.Size = New System.Drawing.Size(455, 23)
        Me.txtLoading.Style = MetroFramework.MetroColorStyle.Lime
        Me.txtLoading.TabIndex = 27
        Me.txtLoading.Theme = MetroFramework.MetroThemeStyle.Dark
        Me.txtLoading.UseStyleColors = True
        '
        'MetroLabel6
        '
        Me.MetroLabel6.AutoSize = True
        Me.MetroLabel6.Location = New System.Drawing.Point(8, 245)
        Me.MetroLabel6.Name = "MetroLabel6"
        Me.MetroLabel6.Size = New System.Drawing.Size(122, 19)
        Me.MetroLabel6.Style = MetroFramework.MetroColorStyle.Lime
        Me.MetroLabel6.TabIndex = 26
        Me.MetroLabel6.Text = "Loading Message : "
        Me.MetroLabel6.Theme = MetroFramework.MetroThemeStyle.Dark
        Me.MetroLabel6.UseStyleColors = True
        '
        'txtLog
        '
        Me.txtLog.FontSize = MetroFramework.MetroTextBoxSize.Medium
        Me.txtLog.FontWeight = MetroFramework.MetroTextBoxWeight.Light
        Me.txtLog.Location = New System.Drawing.Point(12, 511)
        Me.txtLog.Multiline = True
        Me.txtLog.Name = "txtLog"
        Me.txtLog.ReadOnly = True
        Me.txtLog.Size = New System.Drawing.Size(460, 95)
        Me.txtLog.Style = MetroFramework.MetroColorStyle.Orange
        Me.txtLog.TabIndex = 25
        Me.txtLog.Theme = MetroFramework.MetroThemeStyle.Dark
        Me.txtLog.UseStyleColors = True
        '
        'MetroButton2
        '
        Me.MetroButton2.Highlight = True
        Me.MetroButton2.Location = New System.Drawing.Point(478, 585)
        Me.MetroButton2.Name = "MetroButton2"
        Me.MetroButton2.Size = New System.Drawing.Size(124, 21)
        Me.MetroButton2.Style = MetroFramework.MetroColorStyle.Red
        Me.MetroButton2.TabIndex = 24
        Me.MetroButton2.Text = "Create"
        Me.MetroButton2.Theme = MetroFramework.MetroThemeStyle.Dark
        '
        'txtNoNet
        '
        Me.txtNoNet.Location = New System.Drawing.Point(147, 215)
        Me.txtNoNet.Name = "txtNoNet"
        Me.txtNoNet.Size = New System.Drawing.Size(455, 23)
        Me.txtNoNet.Style = MetroFramework.MetroColorStyle.Lime
        Me.txtNoNet.TabIndex = 23
        Me.txtNoNet.Theme = MetroFramework.MetroThemeStyle.Dark
        Me.txtNoNet.UseStyleColors = True
        '
        'MetroLabel5
        '
        Me.MetroLabel5.AutoSize = True
        Me.MetroLabel5.Location = New System.Drawing.Point(8, 216)
        Me.MetroLabel5.Name = "MetroLabel5"
        Me.MetroLabel5.Size = New System.Drawing.Size(118, 19)
        Me.MetroLabel5.Style = MetroFramework.MetroColorStyle.Lime
        Me.MetroLabel5.TabIndex = 22
        Me.MetroLabel5.Text = "No Net Message : "
        Me.MetroLabel5.Theme = MetroFramework.MetroThemeStyle.Dark
        Me.MetroLabel5.UseStyleColors = True
        '
        'txtComp
        '
        Me.txtComp.Location = New System.Drawing.Point(147, 186)
        Me.txtComp.Name = "txtComp"
        Me.txtComp.Size = New System.Drawing.Size(455, 23)
        Me.txtComp.Style = MetroFramework.MetroColorStyle.Lime
        Me.txtComp.TabIndex = 21
        Me.txtComp.Theme = MetroFramework.MetroThemeStyle.Dark
        Me.txtComp.UseStyleColors = True
        '
        'MetroLabel4
        '
        Me.MetroLabel4.AutoSize = True
        Me.MetroLabel4.Location = New System.Drawing.Point(8, 187)
        Me.MetroLabel4.Name = "MetroLabel4"
        Me.MetroLabel4.Size = New System.Drawing.Size(133, 19)
        Me.MetroLabel4.Style = MetroFramework.MetroColorStyle.Lime
        Me.MetroLabel4.TabIndex = 20
        Me.MetroLabel4.Text = "Complete Message : "
        Me.MetroLabel4.Theme = MetroFramework.MetroThemeStyle.Dark
        Me.MetroLabel4.UseStyleColors = True
        '
        'txtWelcome
        '
        Me.txtWelcome.Location = New System.Drawing.Point(147, 157)
        Me.txtWelcome.Name = "txtWelcome"
        Me.txtWelcome.Size = New System.Drawing.Size(455, 23)
        Me.txtWelcome.Style = MetroFramework.MetroColorStyle.Lime
        Me.txtWelcome.TabIndex = 19
        Me.txtWelcome.Theme = MetroFramework.MetroThemeStyle.Dark
        Me.txtWelcome.UseStyleColors = True
        '
        'MetroLabel3
        '
        Me.MetroLabel3.AutoSize = True
        Me.MetroLabel3.Location = New System.Drawing.Point(6, 158)
        Me.MetroLabel3.Name = "MetroLabel3"
        Me.MetroLabel3.Size = New System.Drawing.Size(130, 19)
        Me.MetroLabel3.Style = MetroFramework.MetroColorStyle.Lime
        Me.MetroLabel3.TabIndex = 18
        Me.MetroLabel3.Text = "Welcome Message : "
        Me.MetroLabel3.Theme = MetroFramework.MetroThemeStyle.Dark
        Me.MetroLabel3.UseStyleColors = True
        '
        'txtPhpAddress
        '
        Me.txtPhpAddress.Location = New System.Drawing.Point(401, 104)
        Me.txtPhpAddress.Name = "txtPhpAddress"
        Me.txtPhpAddress.Size = New System.Drawing.Size(201, 23)
        Me.txtPhpAddress.Style = MetroFramework.MetroColorStyle.Lime
        Me.txtPhpAddress.TabIndex = 17
        Me.txtPhpAddress.Text = "http://site.com/server.php"
        Me.txtPhpAddress.Theme = MetroFramework.MetroThemeStyle.Dark
        Me.txtPhpAddress.UseStyleColors = True
        '
        'MetroLabel2
        '
        Me.MetroLabel2.AutoSize = True
        Me.MetroLabel2.Location = New System.Drawing.Point(275, 104)
        Me.MetroLabel2.Name = "MetroLabel2"
        Me.MetroLabel2.Size = New System.Drawing.Size(120, 19)
        Me.MetroLabel2.Style = MetroFramework.MetroColorStyle.Lime
        Me.MetroLabel2.TabIndex = 16
        Me.MetroLabel2.Text = "PHP File Address : "
        Me.MetroLabel2.Theme = MetroFramework.MetroThemeStyle.Dark
        Me.MetroLabel2.UseStyleColors = True
        '
        'txtPhone
        '
        Me.txtPhone.Location = New System.Drawing.Point(147, 129)
        Me.txtPhone.Name = "txtPhone"
        Me.txtPhone.Size = New System.Drawing.Size(124, 23)
        Me.txtPhone.Style = MetroFramework.MetroColorStyle.Lime
        Me.txtPhone.TabIndex = 15
        Me.txtPhone.Theme = MetroFramework.MetroThemeStyle.Dark
        Me.txtPhone.UseStyleColors = True
        '
        'txtMail
        '
        Me.txtMail.Location = New System.Drawing.Point(147, 104)
        Me.txtMail.Name = "txtMail"
        Me.txtMail.Size = New System.Drawing.Size(124, 23)
        Me.txtMail.Style = MetroFramework.MetroColorStyle.Lime
        Me.txtMail.TabIndex = 14
        Me.txtMail.Text = "Ex@mail.com"
        Me.txtMail.Theme = MetroFramework.MetroThemeStyle.Dark
        Me.txtMail.UseStyleColors = True
        '
        'MetroCheckBox2
        '
        Me.MetroCheckBox2.AutoSize = True
        Me.MetroCheckBox2.FontSize = MetroFramework.MetroLinkSize.Medium
        Me.MetroCheckBox2.Location = New System.Drawing.Point(12, 129)
        Me.MetroCheckBox2.Name = "MetroCheckBox2"
        Me.MetroCheckBox2.Size = New System.Drawing.Size(138, 19)
        Me.MetroCheckBox2.Style = MetroFramework.MetroColorStyle.Lime
        Me.MetroCheckBox2.TabIndex = 13
        Me.MetroCheckBox2.Text = "Send SMS Notify : "
        Me.MetroCheckBox2.Theme = MetroFramework.MetroThemeStyle.Dark
        Me.MetroCheckBox2.UseStyleColors = True
        Me.MetroCheckBox2.UseVisualStyleBackColor = True
        '
        'MetroCheckBox1
        '
        Me.MetroCheckBox1.AutoSize = True
        Me.MetroCheckBox1.Checked = True
        Me.MetroCheckBox1.CheckState = System.Windows.Forms.CheckState.Checked
        Me.MetroCheckBox1.Enabled = False
        Me.MetroCheckBox1.FontSize = MetroFramework.MetroLinkSize.Medium
        Me.MetroCheckBox1.Location = New System.Drawing.Point(12, 104)
        Me.MetroCheckBox1.Name = "MetroCheckBox1"
        Me.MetroCheckBox1.Size = New System.Drawing.Size(125, 19)
        Me.MetroCheckBox1.Style = MetroFramework.MetroColorStyle.Lime
        Me.MetroCheckBox1.TabIndex = 12
        Me.MetroCheckBox1.Text = "Send Via Email : "
        Me.MetroCheckBox1.Theme = MetroFramework.MetroThemeStyle.Dark
        Me.MetroCheckBox1.UseStyleColors = True
        Me.MetroCheckBox1.UseVisualStyleBackColor = True
        '
        'pgL
        '
        Me.pgL.Location = New System.Drawing.Point(512, 511)
        Me.pgL.Maximum = 100
        Me.pgL.Name = "pgL"
        Me.pgL.Size = New System.Drawing.Size(45, 41)
        Me.pgL.TabIndex = 11
        Me.pgL.Theme = MetroFramework.MetroThemeStyle.Dark
        '
        'MetroLabel1
        '
        Me.MetroLabel1.AutoSize = True
        Me.MetroLabel1.Location = New System.Drawing.Point(3, 72)
        Me.MetroLabel1.Name = "MetroLabel1"
        Me.MetroLabel1.Size = New System.Drawing.Size(92, 19)
        Me.MetroLabel1.Style = MetroFramework.MetroColorStyle.Blue
        Me.MetroLabel1.TabIndex = 10
        Me.MetroLabel1.Text = "Client Options"
        Me.MetroLabel1.Theme = MetroFramework.MetroThemeStyle.Dark
        Me.MetroLabel1.UseStyleColors = True
        '
        'CnLog
        '
        Me.CnLog.Location = New System.Drawing.Point(134, 46)
        Me.CnLog.Name = "CnLog"
        Me.CnLog.Size = New System.Drawing.Size(482, 23)
        Me.CnLog.Style = MetroFramework.MetroColorStyle.Orange
        Me.CnLog.TabIndex = 9
        Me.CnLog.Text = "Config Not Loaded Yet"
        Me.CnLog.TextAlign = System.Drawing.ContentAlignment.TopLeft
        Me.CnLog.Theme = MetroFramework.MetroThemeStyle.Dark
        Me.CnLog.TileImage = Global.FakeApp_Creator.My.Resources.Resources.ICON
        '
        'btnLoadConfig
        '
        Me.btnLoadConfig.Highlight = True
        Me.btnLoadConfig.Location = New System.Drawing.Point(2, 2)
        Me.btnLoadConfig.Name = "btnLoadConfig"
        Me.btnLoadConfig.Size = New System.Drawing.Size(124, 21)
        Me.btnLoadConfig.Style = MetroFramework.MetroColorStyle.Red
        Me.btnLoadConfig.TabIndex = 8
        Me.btnLoadConfig.Text = "Load Config"
        Me.btnLoadConfig.Theme = MetroFramework.MetroThemeStyle.Dark
        '
        'MetroButton1
        '
        Me.MetroButton1.Highlight = True
        Me.MetroButton1.Location = New System.Drawing.Point(562, 1)
        Me.MetroButton1.Name = "MetroButton1"
        Me.MetroButton1.Size = New System.Drawing.Size(22, 22)
        Me.MetroButton1.Style = MetroFramework.MetroColorStyle.Red
        Me.MetroButton1.TabIndex = 6
        Me.MetroButton1.Text = "-"
        Me.MetroButton1.Theme = MetroFramework.MetroThemeStyle.Dark
        '
        'CnStatus
        '
        Me.CnStatus.Location = New System.Drawing.Point(0, 46)
        Me.CnStatus.Name = "CnStatus"
        Me.CnStatus.Size = New System.Drawing.Size(139, 23)
        Me.CnStatus.Style = MetroFramework.MetroColorStyle.Red
        Me.CnStatus.TabIndex = 5
        Me.CnStatus.Text = "Status : Idle"
        Me.CnStatus.TextAlign = System.Drawing.ContentAlignment.TopLeft
        Me.CnStatus.Theme = MetroFramework.MetroThemeStyle.Dark
        Me.CnStatus.TileImage = Global.FakeApp_Creator.My.Resources.Resources.ICON
        '
        'BtnExit
        '
        Me.BtnExit.Highlight = True
        Me.BtnExit.Location = New System.Drawing.Point(590, 1)
        Me.BtnExit.Name = "BtnExit"
        Me.BtnExit.Size = New System.Drawing.Size(22, 22)
        Me.BtnExit.Style = MetroFramework.MetroColorStyle.Red
        Me.BtnExit.TabIndex = 2
        Me.BtnExit.Text = "X"
        Me.BtnExit.Theme = MetroFramework.MetroThemeStyle.Dark
        '
        'CnTitle
        '
        Me.CnTitle.Location = New System.Drawing.Point(0, 25)
        Me.CnTitle.Name = "CnTitle"
        Me.CnTitle.Size = New System.Drawing.Size(616, 22)
        Me.CnTitle.Style = MetroFramework.MetroColorStyle.Blue
        Me.CnTitle.TabIndex = 3
        Me.CnTitle.Text = "Fake App Creator ( FAC ) | Version 1.0.0 | By @Sahandevs | CyberSoldiersST"
        Me.CnTitle.TextAlign = System.Drawing.ContentAlignment.TopLeft
        Me.CnTitle.Theme = MetroFramework.MetroThemeStyle.Dark
        Me.CnTitle.TileImage = Global.FakeApp_Creator.My.Resources.Resources.ICON
        '
        'OpenFileDialog1
        '
        Me.OpenFileDialog1.Filter = "Fake App Creator Config Files|*.fac"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(616, 611)
        Me.Controls.Add(Me.MetroPanel1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "Form1"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "FAC"
        Me.MetroPanel1.ResumeLayout(False)
        Me.MetroPanel1.PerformLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents MetroPanel1 As MetroFramework.Controls.MetroPanel
    Friend WithEvents BtnExit As MetroFramework.Controls.MetroButton
    Friend WithEvents CnTitle As MetroFramework.Controls.MetroTile
    Friend WithEvents CnStatus As MetroFramework.Controls.MetroTile
    Friend WithEvents MetroButton1 As MetroFramework.Controls.MetroButton
    Friend WithEvents btnLoadConfig As MetroFramework.Controls.MetroButton
    Friend WithEvents CnLog As MetroFramework.Controls.MetroTile
    Friend WithEvents MetroLabel1 As MetroFramework.Controls.MetroLabel
    Friend WithEvents pgL As MetroFramework.Controls.MetroProgressSpinner
    Friend WithEvents MetroCheckBox1 As MetroFramework.Controls.MetroCheckBox
    Friend WithEvents txtMail As MetroFramework.Controls.MetroTextBox
    Friend WithEvents MetroCheckBox2 As MetroFramework.Controls.MetroCheckBox
    Friend WithEvents txtPhone As MetroFramework.Controls.MetroTextBox
    Friend WithEvents txtComp As MetroFramework.Controls.MetroTextBox
    Friend WithEvents MetroLabel4 As MetroFramework.Controls.MetroLabel
    Friend WithEvents txtWelcome As MetroFramework.Controls.MetroTextBox
    Friend WithEvents MetroLabel3 As MetroFramework.Controls.MetroLabel
    Friend WithEvents txtPhpAddress As MetroFramework.Controls.MetroTextBox
    Friend WithEvents MetroLabel2 As MetroFramework.Controls.MetroLabel
    Friend WithEvents txtLog As MetroFramework.Controls.MetroTextBox
    Friend WithEvents MetroButton2 As MetroFramework.Controls.MetroButton
    Friend WithEvents txtNoNet As MetroFramework.Controls.MetroTextBox
    Friend WithEvents MetroLabel5 As MetroFramework.Controls.MetroLabel
    Friend WithEvents txtLoading As MetroFramework.Controls.MetroTextBox
    Friend WithEvents MetroLabel6 As MetroFramework.Controls.MetroLabel
    Friend WithEvents btnPreView As MetroFramework.Controls.MetroButton
    Friend WithEvents OpenFileDialog1 As OpenFileDialog
    Friend WithEvents MetroButton3 As MetroFramework.Controls.MetroButton
    Friend WithEvents MetroButton4 As MetroFramework.Controls.MetroButton
    Friend WithEvents txtmailsubject As MetroFramework.Controls.MetroTextBox
    Friend WithEvents MetroLabel8 As MetroFramework.Controls.MetroLabel
    Friend WithEvents MetroLabel7 As MetroFramework.Controls.MetroLabel
    Friend WithEvents MetroLabel10 As MetroFramework.Controls.MetroLabel
    Friend WithEvents MetroButton5 As MetroFramework.Controls.MetroButton
    Friend WithEvents MetroTextBox1 As MetroFramework.Controls.MetroTextBox
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents MetroLabel9 As MetroFramework.Controls.MetroLabel
    Friend WithEvents TogIp As MetroFramework.Controls.MetroToggle
    Friend WithEvents txtFooter As MetroFramework.Controls.MetroTextBox
    Friend WithEvents MetroLabel14 As MetroFramework.Controls.MetroLabel
    Friend WithEvents txtPageTitle As MetroFramework.Controls.MetroTextBox
    Friend WithEvents MetroLabel13 As MetroFramework.Controls.MetroLabel
    Friend WithEvents MetroLabel15 As MetroFramework.Controls.MetroLabel
    Friend WithEvents MetroToggle1 As MetroFramework.Controls.MetroToggle
    Friend WithEvents lblnosupSENDSMS As MetroFramework.Controls.MetroLabel
    Friend WithEvents MetroLabel16 As MetroFramework.Controls.MetroLabel
    Friend WithEvents MetroButton6 As MetroFramework.Controls.MetroButton
    Friend WithEvents MetroLabel17 As MetroFramework.Controls.MetroLabel
    Friend WithEvents togtele As MetroFramework.Controls.MetroToggle
    Friend WithEvents txtuserid As MetroFramework.Controls.MetroTextBox
    Friend WithEvents MetroLabel12 As MetroFramework.Controls.MetroLabel
    Friend WithEvents MetroLabel11 As MetroFramework.Controls.MetroLabel
    Friend WithEvents txttoken As MetroFramework.Controls.MetroTextBox
    Friend WithEvents lbltele As MetroFramework.Controls.MetroLabel
End Class
